// Faintness file for CS243 Winter 2023, Assignment 4

// Lovish Chopra: lovish@stanford.edu

// Zach Robertson: zroberts@stanford.edu


package flow;


import java.util.*;

import joeq.Compiler.Quad.*;

import joeq.Compiler.Quad.Operand.RegisterOperand;

import joeq.Main.Helper;


public class NullCheck implements Flow.Analysis {


    // Variable set class. This set will store all the faint variables.

    public static class VarSet implements Flow.DataflowObject {

        private Set<String> set;

        public static Set<String> universalSet;

        public VarSet() { set = new TreeSet<String>(); }


        // Top will be the universal set, bottom will be the empty set

        public void setToTop() { set = new TreeSet<String>(universalSet); }

        public void setToBottom() { set = new TreeSet<String>(); }


        // Meet operator for faint variable analysis will be intersection

        public void meetWith(Flow.DataflowObject o)

        {

            VarSet a = (VarSet)o;

            set.retainAll(a.set);

        }


        // Copy a variable set into current object

        public void copy(Flow.DataflowObject o)

        {

            VarSet a = (VarSet) o;

            set = new TreeSet<String>(a.set);

        }


        // Check if variable set contains a specific variable v

        public boolean setContains(String v){

            return set.contains(v);

        }


        // Compare two VarSets

        @Override

        public boolean equals(Object o)

        {

            if (o instanceof VarSet)

            {

                VarSet a = (VarSet) o;

                return set.equals(a.set);

            }

            return false;

        }


        @Override

        public int hashCode() {

            return set.hashCode();

        }

        @Override

        public String toString()

        {

            return set.toString();

        }


        public void genVar(String v) {set.add(v);}

        public void killVar(String v) {set.remove(v);}

    }


    private VarSet[] in, out;

    private VarSet entry, exit;


    public void preprocess(ControlFlowGraph cfg) {

        System.out.println("Method: "+cfg.getMethod().getName().toString());

        /* Generate initial conditions. */

        QuadIterator qit = new QuadIterator(cfg);

        int max = 0;

        while (qit.hasNext()) {

            int x = qit.next().getID();

            if (x > max) max = x;

        }

        max += 1;

        // Create in and out arrays of VarSets, entry and exit

        in = new VarSet[max];

        out = new VarSet[max];

        entry = new VarSet();

        exit = new VarSet();


        // Initialize in[i] and out[i]

        for (int i=0; i<in.length; i++) {

            in[i] = new VarSet();

            out[i] = new VarSet();

        }


        qit = new QuadIterator(cfg);


        // Populate universal set

        Set<String> universalSet = new TreeSet<String>();

        VarSet.universalSet = universalSet;


        // Arguments are always there

        int numargs = cfg.getMethod().getParamTypes().length;

        for (int i = 0; i < numargs; i++) {

            universalSet.add("R" + i);

        }


        // Add all defined and used registers to universal set

        while (qit.hasNext()) {

            Quad q = qit.next();

            for (RegisterOperand def : q.getDefinedRegisters()) {

                universalSet.add(def.getRegister().toString());

            }

            for (RegisterOperand use : q.getUsedRegisters()) {

                universalSet.add(use.getRegister().toString());

            }

        }


        // Set boundary condition and initial conditions

        entry.setToBottom();

        qit = new QuadIterator(cfg);

        while(qit.hasNext()){

            in[qit.next().getID()].setToTop();

        }


        transferfn.val = new VarSet();

        System.out.println("Initialization completed.");

    }


    public void postprocess(ControlFlowGraph cfg) {

        // Print entry, quads and exit

        System.out.println("entry: "+entry.toString());

        for (int i=1; i<in.length; i++) {

            System.out.println(i+" in:  "+in[i].toString());

            System.out.println(i+" out: "+out[i].toString());

        }

        System.out.println("exit: "+exit.toString());

    }


    /* Is this a forward dataflow analysis? */

    public boolean isForward() { return true; }


    /* Routines for interacting with dataflow values. */


    public Flow.DataflowObject getEntry()

    {

        Flow.DataflowObject result = newTempVar();

        result.copy(entry);

        return result;

    }

    public Flow.DataflowObject getExit()

    {

        Flow.DataflowObject result = newTempVar();

        result.copy(exit);

        return result;

    }

    public Flow.DataflowObject getIn(Quad q)

    {

        Flow.DataflowObject result = newTempVar();

        result.copy(in[q.getID()]);

        return result;

    }

    public Flow.DataflowObject getOut(Quad q)

    {

        Flow.DataflowObject result = newTempVar();

        result.copy(out[q.getID()]);

        return result;

    }

    public void setIn(Quad q, Flow.DataflowObject value)

    {

        in[q.getID()].copy(value);

    }

    public void setOut(Quad q, Flow.DataflowObject value)

    {

        out[q.getID()].copy(value);

    }

    public void setEntry(Flow.DataflowObject value)

    {

        entry.copy(value);

    }

    public void setExit(Flow.DataflowObject value)

    {

        exit.copy(value);

    }


    public Flow.DataflowObject newTempVar() { return new VarSet(); }


    /* Actually perform the transfer operation on the relevant

     * quad. */


    private TransferFunction transferfn = new TransferFunction ();

    public void processQuad(Quad q) {

        transferfn.val.copy(out[q.getID()]);

        Helper.runPass(q, transferfn);

        in[q.getID()].copy(transferfn.val);

    }


    /* The QuadVisitor that actually does the computation */

    public static class TransferFunction extends QuadVisitor.EmptyVisitor {

        VarSet val;


        /* For move operation:

           Transfer function is defined by:

            f_b(S) = def(b) U (S - use(b)) if def(b) not in S else S

        */

        @Override

        public void visitNullCheck(Quad q){

            for(RegisterOperand srcvar: q.getUsedRegisters()){

                String src = srcvar.getRegister().toString();

                if(!val.setContains(src)){

                    val.genVar(src);


                }

            }

        }



        /* For other operations:

           Transfer function is defined by:

            f_b(S) = S U def(b) - use(b)

        */

        @Override

        public void visitQuad(Quad q) {

            Operator o = q.getOperator();

            if (!(o instanceof Operator.NullCheck)) {

                for (RegisterOperand def : q.getDefinedRegisters()) {

                    val.killVar(def.getRegister().toString());

                }

            }

        }

    }

}



