package examples;

public class NullCheckExample {
  int add(int[] arr, int i, int j) {
    return arr[i] + arr[j];
  }
}
