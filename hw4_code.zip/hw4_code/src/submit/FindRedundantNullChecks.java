package submit;

import flow.MySolver;
import flow.NullCheck;
import joeq.Class.jq_Class;
import joeq.Main.Helper;

public class FindRedundantNullChecks {

  /*
   * args is an array of class names, e.g. test.SkipList
   * Method should print out a list of quad ids of redundant null checks for each function
   * Please refer to src/test/NullTest.basic.out or src/test/SkipList.basic.out
   */
  public static void main(String[] args) {
    MySolver solver = new MySolver();
    for (int i = 0; i < args.length; i++) {
      jq_Class cls = (jq_Class) Helper.load(args[i]);
      // Find redundant NULL_CHECKs for each class
      // Hint: use MySolver and register a new Analysis
      // get an instance of the analysis class.
      // get an instance of the analysis class.
      String usage = "USAGE: Flow solver-class analysis-class [test-class]+";
      String analysis_name = "NullCheck";
      NullCheck analysis = new NullCheck();
      //try {
      //    Object analysis_obj = Class.forName(analysis_name).newInstance();
      //    analysis = (NullCheck) analysis_obj;
      //} catch (Exception ex) {
      //    System.out.println("ERROR: Could not load class '" + analysis_name + "' as Analysis: " + ex.toString());
      //    System.out.println(usage);
      //    return;
      //}

      solver.registerAnalysis(analysis);
      System.out.println("Now analyzing " + cls.getName());
      Helper.runPass(cls,solver);
    }
  }
}
