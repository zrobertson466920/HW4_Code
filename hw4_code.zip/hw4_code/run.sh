#!/bin/bash
java -cp build/:lib/joeq.jar "$@"